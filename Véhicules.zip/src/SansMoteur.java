public class SansMoteur extends Vehicule {

    public SansMoteur() {
        super();
    }
}
